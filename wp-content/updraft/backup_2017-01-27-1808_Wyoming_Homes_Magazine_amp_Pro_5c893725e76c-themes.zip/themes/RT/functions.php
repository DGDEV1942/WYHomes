<?php 

/* =============================================================================
   DEBUG OPTIONS
   ========================================================================== */
	
	//ini_set( 'display_errors', 1 );
	//error_reporting( E_ERROR | E_WARNING | E_PARSE | E_NOTICE | E_STRICT );	 
	
	//define('WLT_CUSTOMLOGINFORM', false);
	//define('WLT_DEBUG_EMAIL', true);
	//define('WLT_DEBUG_MOBILE', true);
	//define('WLT_DEMOMODE',true);		
 
/* =============================================================================
   LOAD IN FRAMEWORK
   ========================================================================== */
 	
	// LOAD IN CLASS FILES
	if(defined('TEMPLATEPATH') && !defined('THEME_VERSION') ){ include("framework/_config.php"); }	
 	
/* =============================================================================
   ADD YOUR CUSTOM CODE BELOW THIS LINE
   ========================================================================== */
 ?>